import { getTheme } from './themes.js'

// Paintbrush palette (the original cream theme).
export const ACCENT_COLORS = [
  { base: '#78A4C2', dark: '#43535E', light: '#E4EEF4', baseRgb: '120,164,194' }, // Blue   – homepage
  { base: '#78A4C2', dark: '#43535E', light: '#E4EEF4', baseRgb: '120,164,194' }, // Blue   – cat 1
  { base: '#D76969', dark: '#614545', light: '#F4E4E4', baseRgb: '215,105,105' }, // Red    – cat 2
  { base: '#7CBE87', dark: '#435E47', light: '#E4F4E6', baseRgb: '124,190,135' }, // Green  – cat 2
  { base: '#E2AA6A', dark: '#615142', light: '#F6EEE5', baseRgb: '226,170,106' }, // Orange – cat 3
  { base: '#9F7AC2', dark: '#51435E', light: '#EDE5F4', baseRgb: '159,122,194' }, // Purple – cat 4
  { base: '#E1CB76', dark: '#615A43', light: '#F6F2E2', baseRgb: '225,203,118' }, // Yellow – cat 5
  { base: '#D177B0', dark: '#5E4355', light: '#F4E4EE', baseRgb: '209,119,176' }, // Pink   – cat 6
]

export const HOME_ACCENT = ACCENT_COLORS[0]

// The seven hand-picked easel colours, in ring order:
// blue → red → green → orange → purple → yellow → pink → (back to blue).
const N = ACCENT_COLORS.length - 1

const hexToRgb = (hex) => [
  parseInt(hex.slice(1, 3), 16),
  parseInt(hex.slice(3, 5), 16),
  parseInt(hex.slice(5, 7), 16),
]
const rgbToHex = ([r, g, b]) =>
  '#' + [r, g, b].map(v => Math.round(v).toString(16).padStart(2, '0').toUpperCase()).join('')
export const mixHex = (a, b, f) => {
  const A = hexToRgb(a), B = hexToRgb(b)
  return rgbToHex([0, 1, 2].map(i => A[i] + (B[i] - A[i]) * f))
}

// Dark Dots palette. The bases are the theme's own hexes; `dark` stays the same
// bright colour (it reads as the accent on a dark background, where Paintbrush
// used a deeper shade), and `light` is that colour sunk into the page.
const DARK_DOTS_BASES = [
  '#5B8FFF', // Blue   – homepage
  '#5B8FFF', // Blue   – cat 1
  '#FF7070', // Red    – cat 2
  '#54D66E', // Green  – cat 3
  '#F2874D', // Orange – cat 4
  '#B570FF', // Purple – cat 5
  '#E5D950', // Yellow – cat 6
  '#F870FF', // Pink   – cat 7
]

export const DARK_DOTS_COLORS = DARK_DOTS_BASES.map(base => ({
  base,
  dark: base,
  light: mixHex(base, '#212121', 0.72),
  baseRgb: hexToRgb(base).join(','),
}))

// Light Dots: Dark Dots' palette, except yellow, which is too pale to read at
// full strength on the light page. Wherever the easel colour is used solid
// (base / dark) it's the deeper #B0A314; everything drawn at a percentage uses
// baseRgb, which keeps the original yellow — as does `dot`, the colour of the
// easel dots (Gallery header, desktop sidebar) and the page-title dot.
const LIGHT_DOTS_YELLOW = '#B0A314'
export const LIGHT_DOTS_COLORS = DARK_DOTS_COLORS.map(c => (
  c.base === '#E5D950'
    ? { ...c, base: LIGHT_DOTS_YELLOW, dark: LIGHT_DOTS_YELLOW, dot: c.base }
    : c
))

const PALETTES = { paintbrush: ACCENT_COLORS, 'dark-dots': DARK_DOTS_COLORS, 'light-dots': LIGHT_DOTS_COLORS }
const themeColors = () => PALETTES[getTheme()] || ACCENT_COLORS

// The accent the Gallery and the app chrome wear.
export function getHomeAccent() {
  return themeColors()[0]
}

// Where to sit between two neighbouring colours, for successive passes around
// the ring. Repeated bisection: 1/2, then 1/4 and 3/4, then 1/8, 3/8, 5/8, 7/8…
// Every pass halves the previous gaps, so no two easels ever land on the same
// colour no matter how many are added.
function bisectionFraction(pass) {
  const level = Math.floor(Math.log2(pass + 1))   // 0, 1, 1, 2, 2, 2, 2, …
  const i = pass + 1 - 2 ** level                 // position within the level
  return (2 * i + 1) / 2 ** (level + 1)
}

// categoryIndex is the 0-based position of the category in the sorted list.
// 0–6 are the defined colours. Beyond that, each easel takes a colour blended
// between two neighbours: the 8th sits between blue and red, the 9th between
// red and green, and so on round the ring; the 15th then sits between blue and
// the 8th, the 16th between red and the 9th, and so on — each pass subdividing
// the gaps created by the last.
export function getCategoryAccent(categoryIndex) {
  const PALETTE = themeColors().slice(1)
  const i = Math.max(0, categoryIndex | 0)
  if (i < N) return PALETTE[i]

  const m = i - N
  const sector = m % N            // which neighbouring pair to sit between
  const pass = Math.floor(m / N)  // how many times round the ring so far
  const f = bisectionFraction(pass)

  const from = PALETTE[sector]
  const to = PALETTE[(sector + 1) % N]
  // Blend base, dark and light together so the generated set keeps the same
  // relationship between the three that the hand-picked ones have.
  const base = mixHex(from.base, to.base, f)
  // `dot` (and the translucent baseRgb) blend the unadjusted colours, so a
  // theme's solid-only tweak (Light Dots' yellow) stays out of them.
  const dot = mixHex(from.dot ?? from.base, to.dot ?? to.base, f)
  return {
    base,
    dark: mixHex(from.dark, to.dark, f),
    light: mixHex(from.light, to.light, f),
    baseRgb: hexToRgb(dot).map(Math.round).join(','),
    dot,
  }
}

// The Inbox isn't an Easel, so it has no Easel colour: it wears the app's
// neutral text colour instead — the "clear" counterpart to an Easel's accent.
// (baseRgb, which only ever paints washes, is a paler grey than the text
// colour, so the Inbox's fills stay as light as the app's grey controls)
const INBOX_ACCENTS = {
  paintbrush: { base: '#43535E', dark: '#43535E', light: '#E8EBED', baseRgb: '120,140,152' },
  'dark-dots': { base: '#E6E6E6', dark: '#E6E6E6', light: '#3A3A3A', baseRgb: '170,170,170' },
  'light-dots': { base: '#292929', dark: '#292929', light: '#E3E3E3', baseRgb: '150,150,150' },
}
export function getInboxAccent() {
  return INBOX_ACCENTS[getTheme()] || INBOX_ACCENTS.paintbrush
}
